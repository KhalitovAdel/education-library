/* eslint-disable no-undef */
// Конфиг
module.exports = {
    baseUrl: 'http://localhost:8080',
}